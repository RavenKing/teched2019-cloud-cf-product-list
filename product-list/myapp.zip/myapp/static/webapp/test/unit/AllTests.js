sap.ui.define([
	"com/sap/kevin/kevinFront/test/unit/controller/View1.controller"
], function () {
	"use strict";
});